<?php
/*******
 * @package xbArticleManager
 * file administrator/components/com_xbartman/controller.php
 * @version 1.0.0.0 16th January 2019
 * @author Roger C-O
 * @copyright Copyright (c) Roger Creagh-Osborne, 2019
 * @license GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 ******/
defined('_JEXEC') or die();

if (!JFactory::getUser()->authorise('core.manage', 'com_xbartman')) 
{
    throw new JAccessExceptionNotallowed(JText::_('JERROR_ALERTNOAUTHOR'), 403);
}

JLoader::register('XbartmanHelper', __DIR__ . '/helpers/xbartman.php');

$controller = JControllerLegacy::getInstance('xbartman');

$controller->execute(JFactory::getApplication()->input->get('task'));

$controller->redirect();
